install.packages(c("VIM","mice","readr","raster","sp","rgdal","gstat","maptools",
                   "ggplot2","openair","tseries","plyr","dplyr","reshape","ggpubr"))
#加载一些需要的包
install.packages("pacman")
library("pacman")
pacman::p_load(VIM,mice,readr,raster,sp,rgdal,gstat,maptools,ggplot2,openair,tseries,plyr,dplyr,reshape,ggpubr)
#用pacman同时library多个包
pollut <- read_csv("F:/R/R_final_project/南宁2019.csv",
                   col_types = cols(date = col_datetime(format = "%Y/%m/%d %H:%M")))
#整理一下数据
pollut <- data.frame(pollut)
#读取数据看一下数据格式
pollut
head(pollut)

#必须先改变数据格式，把char.改成numeric，否则试过下面画不了图
pollut$CO <- as.numeric(pollut$CO)
pollut$NO2 <- as.numeric(pollut$NO2)
pollut$O3<- as.numeric(pollut$O3)
pollut$PM10 <- as.numeric(pollut$PM10)
pollut$PM2.5 <- as.numeric(pollut$PM2.5)
pollut$SO2 <- as.numeric(pollut$SO2)
pollut$O3_8h <- as.numeric(pollut$O3_8h)

#首先查看一下数据的时间序列图，看看是否存在缺失或者异常
plot.ts(subset(pollut, select = -date),col="purple")
#用subset()函数查询筛选，select表示显示选定列，加上-表示排除指定列，这里
#我们不用看日期，然后用plot.ts()函数将剩下的变量显示出来
summaryPlot(pollut)

#绘制污染物日历图
#绘制PM2.5日历图
#调用openair中的calendarPlot函数：pollutant参数选定展示变量名
calendarPlot(pollut, pollutant = "PM2.5") 
#图的标题为“Daily PM2.5 in 2019”，main表示图的标题
breaks <- c(0,35,75,115,150,250,350)
labels <- c("优","良","轻度污染","中度污染","重度污染","严重污染")
cols=c("green","yellow","orange","red","purple","maroon")
calendarPlot(pollut, pollutant = "PM2.5", breaks =breaks, 
             labels = labels, cols=cols, statistic="mean", main="Daily PM2.5 in 2019")

#绘制CO日历图
calendarPlot(pollut, pollutant = "CO")
breaks <- c(0,5,10,35,60,90,120)
labels <- c("优","良","轻度污染","中度污染","重度污染","严重污染")
cols=c("green","yellow","orange","red","purple","maroon")
calendarPlot(pollut, pollutant = "CO", breaks =breaks, 
             labels = labels, cols=cols, statistic="mean", main="Daily CO in 2019")

#绘制NO2日历图
calendarPlot(pollut, pollutant = "NO2")
breaks <- c(0,40,80,180,280,565,750)
labels <- c("优","良","轻度污染","中度污染","重度污染","严重污染")
cols=c("green","yellow","orange","red","purple","maroon")
calendarPlot(pollut, pollutant = "NO2", breaks =breaks, 
             labels = labels, cols=cols, statistic="mean", main="Daily NO2 in 2019")

#绘制O3
calendarPlot(pollut, pollutant = "O3_8h")
#O3浓度一般采用8小时滑动平均值浓度，计算O3的8小时滑动平均浓度：
ozonedata<-rollingMean(pollut, pollutant = "O3", hours=8)
ozonedata <- na.omit(ozonedata)
calendarPlot(ozonedata, pollutant = "O3", cols = "jet", 
             statistic = "max", main="图1：2019年O3每日最大8小时滑动平均浓度")
#用已有8h滑动平均数据画，两者前后移动了几格，可能由于起始地选择不同
#不影响变化趋势相同
#但是图中的星期几不知道要怎么用英文显示出来，没有查到
breaks <- c(0,100,160,215,265,800)
labels <- c("优","良","轻度污染","中度污染","重度污染")
calendarPlot(pollut, pollutant = "O3_8h", 
             labels = labels, cols="jet", statistic="max",
             main="图2：2019年O3每日最大8小时滑动平均浓度",
             family = "SimSum")

#绘制污染物的时间变化趋势
trendLevel(pollut,pollutant = "PM2.5", X="season", y="hour")
percentile <- function(x)quantile(x,probs = 0.95, na.rm = TRUE)
trendLevel(pollut,"CO",x="month",y="hour",statistic = percentile)

#用timeVariation()函数绘制时间变化图
timeVariation(pollut, pollutant = c("SO2","NO2","CO","O3","PM10","PM2.5"),
              statistic = "mean")
#不同污染物量级不同，除以各自均值，在同一数值范围可比,pollutant参数也可以画单个
#变量，函数默认的统计方法（statistic）为均值和5/95分位数选择“medium”等，展示中位值和5/95、25/75分位数
timeVariation(pollut, pollutant = c("SO2","NO2","CO","O3","PM10","PM2.5"),
              normalise = TRUE)  #默认为FALSE

#计算粗颗粒物浓度及其差值
timeVariation(pollut,pollutant = c("PM2.5","PM10"),difference = TRUE)
#增加粗颗粒物和SO2/NO2比值
pollut2 <- mutate(pollut, coarse=PM10-PM2.5,SN=SO2/NO2)
timeVariation(pollut2, pollutant = "coarse",group = "season")
#melt()函数整齐数据
data2 <- melt(pollut2, id.vars = "date",
            variable.name = "pollutants", value.name = "conc")

#ggplot2画分面图展示各污染物的时间变化序列
plyr::rename(data2,c(variable="pollutants",value="conc"))
data_value<-as_tibble(data2)
data_value
ggplot(data2, aes(x=date, y=value, color = variable))+
  geom_line(size=0.4)+facet_grid(variable~.,scales = "free")+
  theme(strip.text = element_text(face = "bold", size = rel(1.2)),
        strip.background = element_rect(fill = "lightblue",colour = "black",size = 0.5),
        axis.title = element_text(face = "bold"))+ylab("Conc. (ug/m3)")
str

#整理筛选数据，ggplot绘制分季节日变化
pollut1 <- as_tibble(pollut)
pollut1 %>% 
  select(date,CO,NO2,SO2,PM2.5,PM10,O3) %>% 
  filter(CO<0&SO2<0,NO2<0,O3<0,PM2.5<0,PM10<0)
str(pollut1)
so2Output <- timeVariation(pollut1, pollutant = "SO2",group = "season")
no2Output <- timeVariation(pollut1, pollutant = "NO2",group = "season")
coOutput <- timeVariation(pollut1, pollutant = "CO",group = "season")
o3Output <- timeVariation(pollut1, pollutant = "O3",group = "season")
pm2.5_Output <- timeVariation(pollut1, pollutant = "PM2.5",group = "season")
pm10_Output <- timeVariation(pollut1, pollutant = "PM10",group = "season")
so2diurnal <- so2Output$data$hour
no2diurnal <- no2Output$data$hour
codiurnal <- coOutput$data$hour
o3diurnal <- o3Output$data$hour
pm2.5_diurnal <- pm2.5_Output$data$hour
pm10_diurnal <- pm10_Output$data$hour

plist <- list()
names(so2diurnal)[1]<-"Season"
plist[[1]] <- ggplot(so2diurnal,aes(x=hour,y=Mean,fill=Season))+
  geom_ribbon(aes(ymin=Lower,ymax=Upper),alpha=0.6)+
  geom_line(size=1.01)+
  theme(axis.title.x=element_text(colour="black",face="bold"),
        axis.text.x = element_text(colour = "black"),
        axis.title.y=element_text(colour="black",face="bold"),
        axis.text.y = element_text(colour = "black"),
        strip.text = element_text(face = "bold",size = rel(1.05)),
        strip.background = element_rect(fill = "#d1eeee"),
        legend.position = "bottom")+
  scale_fill_manual(values=c("#CCCCFF","#CCFFCC","#99CCFF","#FFCCCC"),
                    guide=guide_legend(title = NULL))+xlab("Local time (h)")+
  ylab("Mean and 95% confidence interval in mean")

names(no2diurnal)[1]<-"Season"
plist[[2]] <- ggplot(no2diurnal,aes(x=hour,y=Mean,fill=Season))+
  geom_ribbon(aes(ymin=Lower,ymax=Upper),alpha=0.6)+
  geom_line(size=1.01)+
  theme(axis.title.x=element_text(colour="black",face="bold"),
        axis.text.x = element_text(colour = "black"),
        axis.title.y=element_text(colour="black",face="bold"),
        axis.text.y = element_text(colour = "black"),
        strip.text = element_text(face = "bold",size = rel(1.05)),
        strip.background = element_rect(fill = "#d1eeee"),
        legend.position = "bottom")+
  scale_fill_manual(values=c("#CCCCFF","#CCFFCC","#99CCFF","#FFCCCC"),
                    guide=guide_legend(title = NULL))+xlab("Local time (h)")+
  ylab("Mean and 95% confidence interval in mean")

#试过用melt()函数融合Xdiurnal，然后用facet_wrap把图把图画在一起的没有成功
#通过学习，后来单个画图，然后用ggarrange包进行了图形组合
ggarrange(plotlist=plist,
          ncol=1,
          nrow=length(plist),
          heights=c(1,1) ,
          align="v")
ggsave(fn_fig1a, height=8, width=14)

#通过假定污染物之间存在线性关系来计算污染物之间比值的时间变化规律，使用linearRelation
#函数展示污染物之间的斜率的时间变化特征,period还可以调整为monthly, weekly 
linearRelation(pollut,x="SO2",y="NO2",period = "day.hour",cols = "red") 
linearRelation(pollut,x="PM10",y="PM2.5",period = "day.hour",cols = "green")
linearRelation(pollut,x="O3",y="NO2",period = "day.hour",cols = 'purple')

#Part2(AQI时间序列)
# Read data
Keeling_Data <- read.csv(file = "F:/R/R_final_project/南宁2019.csv", header = T)
# Handel missing values
Keeling_Data$AQI[which(Keeling_Data$AQI<0)] <- NA

for(i in 1:length(Keeling_Data$AQI)){
  if( is.na(Keeling_Data$AQI[i])){
    Keeling_Data$AQI[i] <- mean(Keeling_Data$AQI[(i-1):(i+1)],na.rm=T )
  }
}
# Apply the ts() function
D1 <- c(Keeling_Data$AQI)
D1
dt <- as.Date(Keeling_Data[,1])
dt
AQI_ts <- ts(D1, start=c(1,1), frequency=1)
# Quick plot
plot(AQI_ts, type="l",col = "brown")
str(AQI_ts)
AQI_ts <- na.omit(AQI_ts)
acf(AQI_ts)
pacf(AQI_ts)
#从前面的分析可以得知大气污染物的时间序列数据具有一定的周期性（包括
#明显的季节型波动、周—日变化等），简单分析一下数据的自相关性和偏相关
#性，由图14和15可见，PM2.5浓度ACF拖尾，PACF在1步截尾(p=1),说明AQI的
#时间序列可能是平稳性时间序列，用自回归滑动平均模型（ARMA）做时化趋
#势的预测分析，数据集不满足分析季节性因素的分解要求，数据足够时详细
#的时间变化预测建模

#PART3:NO2多元回归分析
#(1)数据集选择
#数据集有8个观测点的较完整时间数据，绘制NO2分布的盒图和小提琴图
install.packages("vioplot")
library(vioplot)
df <- read.csv("F:/R/R_final_project/shujuxuanze.csv")
df
p <- ggviolin(df, x = "station", y = 'Value',
              fill = "station",
              add = 'boxplot',
              add.params = list(fill = 'white'),
              palette = "jco", 
              ggtheme = theme_bw(), legend = "top")
p
#按照均值从从低到高排列，发现8个观测点NO2的分布基本相似
#(2)看变量之间的相关关系，进行直观感受与定性分析
plot(NO2~CO, data=pollut_tbl)
plot(NO2~SO2,data=pollut_tbl)
plot(NO2~O3,data=pollut_tbl)
plot(NO2~PM2.5,data=pollut_tbl)
plot(NO2~PM10,data=pollut_tbl)

#PART4:空间插值部分
#读取数据
Data<-na.omit(read.csv("F:/R/R_final_project/南宁市2019年1月.csv",header=T))
head(Data)
plot(sort(Data$AQI), ylab="AQI", las=1, xlab='站点')
bound<-readOGR("F:/R/R_final_project/城区/城区.shp")
class<-readOGR("F:/R/R_final_project/城区/class.shp")
plot(bound,col="grey")
bound1 <- raster::aggregate(bound)
##设定AQI的投影为WGS84
dsp <- SpatialPoints(Data[,5:6], proj4string=CRS("+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0"))
dsp <- SpatialPointsDataFrame(dsp,Data)
#展示更直观的地图
cuts<-c(0,5,10,25,50,75)#设置间距
red_blues <- colorRampPalette(c("red","blue"))(5)#设置颜色梯度
pols <- list("sp.polygons", bound, fill = "lightgray")#构建南宁市的SpatialPolygons对象
spplot(dsp, cuts=cuts, col.regions = red_blues, sp.layout=pols, pch=13, cex=2)

#将经纬度转成平面坐标，使插值结果与数据保持一致,这里用到的坐标系也是WGS84
WGS84<- CRS("+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0")#设置参考系WGS84
dsp1<-spTransform(dsp,WGS84)#将经纬度转成平面坐标，使用WGS参考系
bound1<-spTransform(bound,WGS84)
#使用领域多边形插值
install.packages(c("dismo","deldir","rgeos"))
pacman::p_load(rgeos,deldir,dismo)
v<-voronoi(dsp1)
v1 <- rgeos::intersect(v,bound1)
plot(v)
bound2<-aggregate(bound1)#聚合，降低分辨率
v1<-intersect(v,bound2)#将两个图层相交
spplot(v1,"AQI", col.regions=rev(get_col_regions()))#绘制多边形图


